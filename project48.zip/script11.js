
      let a = document.getElementById("button-addon2")
      a.addEventListener("click",addChapter);
      function addChapter(e){
        if(parList.children[0].className=="Msg"){
          parList.children[0].remove();
        }
        let b = e.currentTarget;
        let c = b.previousElementSibling;
        let currentWord = c.value;

        let newLi = document.createElement("li");
        //newLi.classList.add("list-group-item");
        //   OR
        newLi.className = "list-group-item";
        newLi.innerHTML =`<h4 class="pri">${currentWord}</h4>
              <button type="button" onclick="editChapter(this)" class="btn btn-danger">Edit</button>
              <button type="button" onclick="removeChapter(this)" class="btn btn-warning">Remove</button>`
        parList.appendChild(newLi);
      }
      function removeChapter(currElement){
        console.log(currElement)
       currElement.parentElement.remove();
       if(parList.children.length<=0){
        let msg = document.createElement("h3");
        msg.className = "Msg"
        msg.innerHTML = "Nothing is Present in List"
        parList.appendChild(msg)
       }
      }
      function editChapter(currElement){
        if(currElement.textContent=="Done"){
          currElement.textContent = "Edit";
          let currChap = currElement.previousElementSibling.value;
          let currHeading = document.createElement("h4");
          currHeading.className = 'pri'
          currHeading.textContent = currChap;
          currElement.parentElement.replaceChild(currHeading,currElement.previousElementSibling);
        }
        else{
        currElement.textContent = "Done"
        let currChap = currElement.previousElementSibling.textContent;
        let currInput = document.createElement("input");
        currInput.type = "text";
        currInput.className = "form-control mr-1";
        currInput.placeholder = "Type Here"
        currInput.value = currChap;
        currElement.parentElement.replaceChild(currInput,currElement.previousElementSibling);
        }
      }
    